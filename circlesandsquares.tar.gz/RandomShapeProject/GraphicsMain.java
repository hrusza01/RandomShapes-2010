/** 
By Zach Hruska
*/

import javax.swing.*;

public class GraphicsMain
{
	public static void main(String[] args)
	{
		GraphicsFrame gframe = new GraphicsFrame();

		gframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gframe.setVisible(true);
	}
}
